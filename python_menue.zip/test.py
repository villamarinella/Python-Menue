#!/usr/bin/python
# -*- coding: utf-8 -*-

from ttk import Frame, Button, Style
import tkMessageBox as box
from Tkinter import *
import subprocess
import tkFont
import sys
import netifaces as ni
import math
#import picamera
#import RPi.GPIO as GPIO
from Tkinter import Frame, Tk, BOTH, Text, Menu, END
import tkFileDialog 
import tkColorChooser 
import subprocess
import os
import sys

print "You have all you need"




